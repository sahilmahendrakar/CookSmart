package sahilmahendrakar;

import java.util.ArrayList;

public class Recipe {
	private String name;
	private ArrayList<Ingredient> ingredients;
	private int rating;
	private int calories;


	
	Recipe(String name, ArrayList<Ingredient> ingredients, int calories){
		this.name = name;
		this.ingredients = ingredients;	
		this.calories = calories;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Ingredient> getIngredients() {
		return ingredients;
	}

	public void setIngredients(ArrayList<Ingredient> ingredients) {
		this.ingredients = ingredients;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public int getCalories() {
		return calories;
	}

	public void setCalories(int calories) {
		this.calories = calories;
	}



	public int numOfIngredientsMissing(ArrayList<Ingredient> inputIngredients) {
		int numIngredientsMissing = 0;
		for(Ingredient i:ingredients) {
			//System.out.println("Checking: " + i.getName());
			if(!ingredientCheck(i, inputIngredients)) {
				numIngredientsMissing++;
				System.out.println(numIngredientsMissing);
			}
		}
		return numIngredientsMissing;
	}

	public ArrayList<Ingredient> missingIngredients(ArrayList<Ingredient> inputIngredients){
		ArrayList<Ingredient> missingIngredient = new ArrayList<>();
		for(Ingredient i:ingredients) {
			//System.out.println("Checking: " + i.getName());
			if(!ingredientCheck(i, inputIngredients)) {
				missingIngredient.add(i);
			}
		}
		return missingIngredient;
	}
	
	public boolean ingredientCheck(Ingredient i, ArrayList<Ingredient> inputIngredients) {
		for (Ingredient input:inputIngredients) {
			if(i.getName().equals(input.getName())) {
				if(i.getQuantity()<input.getQuantity()) {
					//System.out.println(i.getName() + " matched with " + input.getName());
					return true;
				}
			}
		}
		return false;
	}
}
