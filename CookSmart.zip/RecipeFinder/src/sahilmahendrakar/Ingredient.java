package sahilmahendrakar;

public class Ingredient {
	private String name;
	private double quantity;
	
	
	Ingredient(String name, double quantity){
		this.name = name;
		this.quantity = quantity;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	
	public int checkIngredient(String input, double inputNumber) {
		if (input == name) { 
			if(inputNumber > quantity) {
				return 0;
			}
			else return 1;
		}
		else return 2;
	}
}
