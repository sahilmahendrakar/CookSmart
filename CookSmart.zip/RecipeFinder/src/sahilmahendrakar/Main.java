package sahilmahendrakar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		ArrayList<Recipe> loadedRecipes = recipeReader();
		/*for (Recipe r:loadedRecipes) {
			read("recipe name: " + r.getName());
			for(Ingredient i:r.getIngredients()) {
				System.out.print("ingredient name: " + i.getName());
				read("... Quantity: " + i.getQuantity());
			}
			read("");
		}*/

		String input = "";
		read("");
		read("Type ingredients that you have. \nType finished when done inputting ingredients");
		ArrayList<Ingredient> ingredients = new ArrayList<>();
		while(!checkNo(input)) {
			read("What is the name of the ingredient?");
			String ingredientName = getInput();
			if(checkNo(ingredientName)||ingredientName.contains("stop")||ingredientName.contains("finished")){
				break;
			}
			double quantity = 0;
			while(true) {
				read("How much of the ingredient do you have");
				try {
					quantity = Double.valueOf(getInput().replaceAll("\\D+",""));
					break;
				}
				catch(NumberFormatException e) {
					read("Please enter a number");
				}
			}
			Ingredient ingredient = new Ingredient(ingredientName, quantity);
			ingredients.add(ingredient);
			read(ingredientName.substring(0, 1).toUpperCase() + ingredientName.substring(1).toLowerCase() + " added");
		}
		ArrayList<Recipe> noIngredientsMissing = new ArrayList<>();
		ArrayList<Recipe> oneIngredientMissing = new ArrayList<>();
		ArrayList<Recipe> twoIngredientsMissing = new ArrayList<>();
		ArrayList<Recipe> threeIngredientsMissing = new ArrayList<>();
		for(Recipe recipe:loadedRecipes) {
			switch(recipe.missingIngredients(ingredients).size()) {
			case 0: noIngredientsMissing.add(recipe); break;
			case 1: oneIngredientMissing.add(recipe); break;
			case 2: twoIngredientsMissing.add(recipe); break;
			case 3: threeIngredientsMissing.add(recipe); break;
			}
		}
		read("");
		if(noIngredientsMissing.size()>0) {
			read("You can make: ");
			for(Recipe r:noIngredientsMissing) {
				read(r.getName());
				read("Calories: " + r.getCalories());
			}
			read("");
		}
		else read("You don't have enough ingredients for any recipe \n");
		if(oneIngredientMissing.size()>0) {
			read("You are missing one ingredient for the following recipe:");
			for(Recipe r:oneIngredientMissing) {
				read(r.getName());
				read("Calories: " + r.getCalories());
				read("Missing Ingredients:");
				for(Ingredient i:r.missingIngredients(ingredients)) {
					read(i.getName());
				}
				read("");
			}

		}
		if (twoIngredientsMissing.size()>0) {
			read("You are missing two ingredients for the following: ");
			for(Recipe r:twoIngredientsMissing) {
				read(r.getName());
				read("Calories: " + r.getCalories());
				read("Missing Ingredients:");
				for(Ingredient i:r.missingIngredients(ingredients)) {
					read(i.getName());
				}
				read("");
			}

		}
		if (threeIngredientsMissing.size()>0) {
			read("You are missing three ingredients for the following: ");
			for(Recipe r:threeIngredientsMissing) {
				read(r.getName());
				read("Calories" + r.getCalories());
				read("Missing Ingredients:");
				for(Ingredient i:r.missingIngredients(ingredients)) {
					read(i.getName());
				}
				read("");
			}


		}
		/*for(Recipe recipe:recipeReader()) {
			read("Recipe Name: " + recipe.getName());
			for(Ingredient i:recipe.getIngredients()) {
				read("Ingredient Name: " + i.getName());
				read("Quantity: " + i.getQuantity());
			}
		}*/
	}

	public static ArrayList<Recipe> recipeReader() throws FileNotFoundException{
		File file = new File("files/recipes.txt");
		Scanner scanner = new Scanner(file);
		ArrayList<Recipe> recipes = new ArrayList<>();
		try {
			while(scanner.hasNextLine()) {
				String line = scanner.nextLine();
				//read(line);
				if(line.contains("R<")) {
					String recipeName = line.substring(line.indexOf("R<")+2, line.indexOf(">R"));
					//read(recipeName);
					ArrayList<Ingredient> ingredients = new ArrayList<>();
					int calories = 0;
					double quantity = 0;
					String ingredientName = "";
					String nextLine = scanner.nextLine();
					while((nextLine.contains("N<")||nextLine.contains("I<")||nextLine.contains("C<"))&&scanner.hasNextLine()) {
						//read(nextLine);
						if(nextLine.contains("C<")) {
							calories = Integer.valueOf(nextLine.substring(nextLine.indexOf("C<")+2, nextLine.indexOf(">C")));
						}
						else{
							if(nextLine.contains("N<")) {
								quantity = Double.valueOf(nextLine.substring(nextLine.indexOf("N<")+2, nextLine.indexOf(">N")));
							}
							if(nextLine.contains("I<")) {
								ingredientName = nextLine.substring(nextLine.indexOf("I<")+2, nextLine.indexOf(">I"));
							}

							Ingredient i = new Ingredient(ingredientName, quantity);
							ingredients.add(i);
						}
						nextLine = scanner.nextLine();
						//read(nextLine);
					}
					Recipe recipe = new Recipe(recipeName, ingredients, calories);
					recipes.add(recipe);
					System.out.println(recipe.getName() + " loaded");
					delay(0.2);
					/*do {
						String nextLine = scanner.nextLine();
						if(nextLine.contains("N<")) {
							quantity = Integer.valueOf(nextLine.substring(nextLine.indexOf("N<")+2, nextLine.indexOf(">N")));
						}
						if(nextLine.contains("I<")) {
							ingredientName = nextLine.substring(nextLine.indexOf("I<")+2, nextLine.indexOf(">I"));
						}
						Ingredient i = new Ingredient(ingredientName, quantity);
						ingredients.add(i);
					} while(!nextLine.contains("R<"));
					Recipe recipe = new Recipe(recipeName, ingredients);
					recipes.add(recipe);*/
				}
			}
			return recipes;
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public static String getInput() {
		Scanner scanner = new Scanner(System.in);
		return scanner.nextLine();
	}
	//creates a method that returns a boolean. Talks in to strings and checks if the first string contains the second string.
	public static boolean hasWord(String input, String word) {
		//splits the input into words and stores it in an array of strings
		String[] inputs = input.split(" ");
		//uses a for loop to check if any word matches the given word
		for(String inputWord:inputs) {
			//sets input to lower case and checks if it matches the given word
			if (inputWord.toLowerCase().equals(word)) {
				return true;
			}
		}
		return false;
	}

	//Automatically takes in input and has more versatility. Useful to tell if the person said yes or no in a single method
	//returns 0 if the person said yes. Returns 1 if the person said no. Returns 2 if the person didn't say yes or no.
	public static boolean checkYes() {
		while(true) {
			//uses getInput method to take in user input and sets it to lower case
			String input = getInput().toLowerCase();
			//checks if the input contains a yes word using the checkYes method
			if (checkYes(input)) {
				return true;
			}
			//checks if the input contains a no word using the checkNo method
			else if (checkNo(input)) {
				return false;
			}
			//if it doesn't contain a recognized yes or no word it returns 2
			else read("Please say yes or no");
		}
	}

	//Takes in user input and checks if the user inputed a yes word
	public static boolean checkYes(String input) {
		//uses the has word input and checks if the input has any of the following words: yes, ya, sure, ok, yeah
		if (hasWord(input, "yes")||hasWord(input, "ya")||hasWord(input, "sure")||hasWord(input, "ok")||hasWord(input, "yeah")) {
			return true;
		}
		else return false;
	}



	//takes in input and checks if it has a no word
	public static boolean checkNo(String input) {
		//checks if the user has any the following words: no, nope, or nah. Uses hasWord method.
		if (hasWord(input, "no")||hasWord(input, "nope")||hasWord(input, "nah")) {
			return true;
		}
		else return false;
	}

	//method takes in a double and delays for that amount of time
	public static void delay(double seconds) {
		//this try catch block is used to make a delay. A try catch is needed in case the delay is interrupted and there is an error
		try {
			//converts the inputed seconds to milliseconds
			Thread.sleep((int) (seconds*1000));
			//catches an interrupted error
		} catch (InterruptedException e) {
			//prints the error
			e.printStackTrace();
		}
	}
	//This method prints out lines with a delay
	public static void read(String input) {
		//Splits the input by the "\n" and stores it as different elements in an array of strings
		String[] inputs = input.split("\n");
		//uses a for loop to print each line out with a delay
		for (String s:inputs) {
			System.out.println(s);
			delay(1);
		}
	}
}

